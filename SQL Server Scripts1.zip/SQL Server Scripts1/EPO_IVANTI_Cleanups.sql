-------------housekeeping for EPO and IVANTI (sx) database
-----------------------------------------------------------
USE [SQL_Monitoring]
GO

/****** Object:  StoredProcedure [dbo].[ClearOutdatedLumensionData]    Script Date: 7/17/2023 1:50:47 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



ALTER PROCEDURE [dbo].[ClearOutdatedLumensionData]
 
AS

BEGIN

  ----------------------------------------------------------------------------------------------------
                                                
  ---------------------------------------------------------------------------------------------------- 
-- Description:   <delete all logs older than the specified date that aren't MEDIUM-ENCRYPTED>
-- =============================================
 
      SET NOCOUNT ON
      
      DECLARE @inBatchSize AS INT
      SET @inBatchSize = 100000

      DECLARE @inCutOffTime AS DATETIME
      SET @inCutOffTime = DATEADD(DAY, -400, GETUTCDATE())

      WHILE (SELECT COUNT(*) FROM sx.ActivityLog.Entry WHERE UTCDateTime < @inCutOffTime and ActionID <> 12) <> 0
      BEGIN
      
            DECLARE @EntryIDToDrop TABLE (EntryID BIGINT PRIMARY KEY NOT NULL)
            
            INSERT INTO @EntryIDToDrop 
                  SELECT TOP (@inBatchSize) EntryID 
                  FROM sx.ActivityLog.Entry
                              LEFT OUTER JOIN sx.ActivityLog.[User] ON sx.ActivityLog.Entry.UserID = sx.ActivityLog.[User].UserID  
                  WHERE UTCDateTime < @inCutOffTime
                        AND ActionID <> 12
                  ORDER BY EntryID ASC

            SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
            SET XACT_ABORT ON
            
            BEGIN TRAN
            
                  DELETE FROM sx.ActivityLog.ShadowLocation WHERE EntryID in (SELECT EntryId FROM @EntryIDToDrop)
            
                  DELETE FROM sx.ActivityLog.Entry_Data WHERE EntryID in (SELECT EntryId FROM @EntryIDToDrop)
            
                  DELETE FROM sx.ActivityLog.Entry WHERE EntryID in (SELECT EntryId FROM @EntryIDToDrop)
                  
            COMMIT TRAN
      END

  ----------------------------------------------------------------------------------------------------

END

GO


USE [SQL_Monitoring]
GO

/****** Object:  StoredProcedure [dbo].[ClearOutdatedMcAfeeData]    Script Date: 7/17/2023 1:50:54 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
------------------------------------

USE [msdb]
GO

/****** Object:  Job [ISE_DatabaseMaint// Clear Outdated Lumension Data]    Script Date: 7/17/2023 2:39:40 PM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 7/17/2023 2:39:40 PM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'ISE_DatabaseMaint// Clear Outdated Lumension Data', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'Clears data that is older than 400 days from the Lumension Database', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', 
		@notify_email_operator_name=N'SQL_DBA_SUPPORT', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Step 1]    Script Date: 7/17/2023 2:39:40 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Step 1', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec dbo.[ClearOutdatedLumensionData]', 
		@database_name=N'SQL_Monitoring', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Database Maintenance - Lumension', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=64, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20170326, 
		@active_end_date=99991231, 
		@active_start_time=30000, 
		@active_end_time=235959, 
		@schedule_uid=N'd51cd596-7f6e-44bf-99b7-efc68a26de7c'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO
-----------------------------------------------------------------------------------
USE [msdb]
GO

/****** Object:  Job [ISE_DatabaseMaint// Clear Outdated McAfee Data]    Script Date: 7/17/2023 2:39:55 PM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 7/17/2023 2:39:55 PM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'ISE_DatabaseMaint// Clear Outdated McAfee Data', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', 
		@notify_email_operator_name=N'SQL_DBA_SUPPORT', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [ClearOutdatedMcAfeeData]    Script Date: 7/17/2023 2:39:55 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'ClearOutdatedMcAfeeData', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec dbo.[ClearOutdatedMcAfeeData]', 
		@database_name=N'SQL_Monitoring', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Index maintainance ePO5_10_SLKBRHEP02_Events]    Script Date: 7/17/2023 2:39:55 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Index maintainance ePO5_10_SLKBRHEP02_Events', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXECUTE dbo.IndexOptimize
@Databases = ''ePO5_10_SLKBRHEP02_Events'',
@FragmentationLow = NULL,
@FragmentationMedium = ''INDEX_REORGANIZE,INDEX_REBUILD_ONLINE,INDEX_REBUILD_OFFLINE'',
@FragmentationHigh = ''INDEX_REBUILD_ONLINE,INDEX_REBUILD_OFFLINE'',
@FragmentationLevel1 = 5,
@FragmentationLevel2 = 30,
@UpdateStatistics = ''ALL'',
@OnlyModifiedStatistics = ''Y''', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Clear Outdated McAfee Data', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20170326, 
		@active_end_date=99991231, 
		@active_start_time=220000, 
		@active_end_time=235959, 
		@schedule_uid=N'495bc52c-4898-4058-afe7-1fc4406bf0fc'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

---------------------------------------------------------------------------------------------


