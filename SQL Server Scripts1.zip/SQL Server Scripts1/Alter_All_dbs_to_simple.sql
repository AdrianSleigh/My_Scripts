--Generates script to change all databases to simple mode

select 'alter database 
['+name+'] set recovery simple' 
from master.sys.databases where database_id > 4 and state_desc = 'online'