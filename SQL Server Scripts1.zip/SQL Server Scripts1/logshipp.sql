----TEMPORARY CHANGE LOGSHIPPING SECOONDARY TO READ ONLY
----------------------------------------------------------------------
--1 check restiore_mode should be 0

/*
SELECT secondary_database,
restore_mode,
disconnect_users,
last_restored_file
FROM msdb.dbo.log_shipping_secondary_databases

---2. disable restore tlog job on secondary

--3. run on secondary

RESTORE LOG DNNPublic_Live
WITH STANDBY = N'E:\DNNPublic_Live\ROLLBACK_UNDO_DNNPublic_Live.tuf'
GO
*/

-- Statement to execute on the new primary server  
USE msdb  
GO  
EXEC master.dbo.sp_change_log_shipping_secondary_database @secondary_database = N'database_name', @threshold_alert_enabled = 1;  
GO

-- Statement to execute on the new secondary server  
USE msdb  
GO  
EXEC master.dbo.sp_change_log_shipping_primary_database @database=N'database_name', @threshold_alert_enabled = 1;  
GO