SELECT name As BLANK_PASSWORD,type_desc,create_date,modify_date,password_hash 
FROM sys.sql_logins 
WHERE PWDCOMPARE('',password_hash)=1;

SELECT name as PASS_WORD_SAME_USER,type_desc,create_date,modify_date,password_hash 
FROM sys.sql_logins 
WHERE PWDCOMPARE(name,password_hash)=1;

SELECT name FROM sys.sql_logins   
WHERE PWDCOMPARE('password', password_hash) = 1 ;  

SELECT name FROM sys.sql_logins   
WHERE PWDCOMPARE('Pa55w0rd', password_hash) = 1 ;  