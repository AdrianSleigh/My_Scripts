-----INSTANCE LEVEL LAST USED OBJECTS
-------------------------------------------------------------------------
USE MASTER
GO
SELECT
(SELECT sqlserver_start_time FROM sys.dm_os_sys_info)As Last_SQL_Restart, 
b.name AS dbname,c.name AS object_used,a.last_user_seek,a.last_user_scan,
a.last_user_lookup,a.last_user_update,a.user_seeks,a.user_scans,a.user_lookups,a.user_updates

FROM 
sys.dm_db_index_usage_stats a join sysdatabases b  ON a.database_id = b.dbid 
JOIN sysobjects c on a.object_id = c.id
WHERE b.name NOT IN ('master','msdb','temdb')
ORDER BY b.name DESC
