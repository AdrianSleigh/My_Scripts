---------GET DRIVE FREE DISK SPACE
------------------------------------------------------------
SELECT DISTINCT
    SUBSTRING(volume_mount_point, 1, 1) AS Drive_Mount_Point
    ,total_bytes/1024/1024 AS Total_MB
    ,available_bytes/1024/1024 AS Available_MB
    ,ISNULL(ROUND(available_bytes / CAST(NULLIF(total_bytes, 0) AS FLOAT) * 100, 2), 0) as Percent_Available
FROM
    sys.master_files AS f
CROSS APPLY
    sys.dm_os_volume_stats(f.database_id, f.file_id);