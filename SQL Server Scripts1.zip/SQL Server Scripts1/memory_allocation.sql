---MEMORY USAGE
---APS 11/01/21

SELECT 
(total_physical_memory_kb/1024)/1000 AS total_server_memory_GB, (available_physical_memory_kb/1024)/1000 AS Available_memory_GB, system_memory_state_desc ,
b.value_in_use
FROM  sys.dm_os_sys_memory a, sys.configurations b
 WHERE b.[name] = 'max server memory (MB)'
