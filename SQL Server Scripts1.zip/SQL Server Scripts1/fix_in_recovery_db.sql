-- db stuck 'in recovery' fix by .......
--Adrian Sleigh 15/02/17
--This will lose data from the transaction log and should only be used in extreme cases
--substitute databasename [Corruptdb] for suspect db
----------------------------------------
USE master
GO
ALTER DATABASE [Corruptdb] SET EMERGENCY
GO
ALTER DATABASE [Corruptdb] SET SINGLE_USER
GO

---------------------------------------------------
DBCC CHECKDB ([Corruptdb], REPAIR_ALLOW_DATA_LOSS) WITH NO_INFOMSGS, ALL_ERRORMSGS;
GO

--if dbcc checkdb cannot fix there are 2 further options

------------------------ option 1
-- detach database
-- rename .ldf file

CREATE DATABASE [Corruptdb] 
---find location of mdf file
ON (FILENAME = 'C:\Program Files\Microsoft SQL Server\MSSQL13.MSSQLSERVER\MSSQL\DATA\Corruptdb.mdf') 
FOR ATTACH_REBUILD_LOG


------------------------option 2
-- offline database in SSMS
-- rename .ldf file

ALTER DATABASE [Corruptdb] REBUILD LOG ON
(NAME= logicalname, FILENAME='C:\Program Files\Microsoft SQL Server\MSSQL13.MSSQLSERVER\MSSQL\DATA\Corruptdb_log.ldf')
GO

ALTER DATABASE [Corruptdb] SET MULTI_USER
GO
----------------------------------------------------------------------
-----OR TRY THIS -----------------------------------------------------

EXEC sp_resetstatus [Corruptdb];
ALTER DATABASE [Corruptdb] SET EMERGENCY
DBCC checkdb([Corruptdb])
ALTER DATABASE [Corruptdb] SET SINGLE_USER WITH ROLLBACK IMMEDIATE
DBCC CheckDB ('Corruptdb', REPAIR_ALLOW_DATA_LOSS)
ALTER DATABASE [Corruptdb] SET MULTI_USER

DBCC CHECKDB ([Corruptdb])

--- all fixed----------------------