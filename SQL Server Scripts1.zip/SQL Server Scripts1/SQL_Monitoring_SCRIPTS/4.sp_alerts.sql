USE [SQL_Monitoring]
GO

/****** Object:  StoredProcedure [dbo].[sp_alert_backup]    Script Date: 1/10/2023 2:59:09 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[sp_alert_backup]

AS

-- =============================================
-- Author:		Adrian Sleigh
-- Create date: 2022/03/16 V2.0
-- Item:	sp_alert_backup sends email alert on issues
-- Description Part of suite of scripts for monitoring
-- =============================================

SELECT getdate()AS run_date,
SUBSTRING(B.name,1,30) AS Database_Name, ISNULL(STR(ABS(DATEDIFF(day, GetDate(), 
                MAX(Backup_finish_date)))), 'NEVER') AS DaysSinceLastBackup,
                ISNULL(Convert(char(10), MAX(backup_finish_date), 101), 'NEVER') AS LastBackupDate,
				A.type AS 'TYPE'
 INTO ##LastBackup 
                FROM MASTER.dbo.sysdatabases B LEFT OUTER JOIN MSDB.dbo.backupset A 
                ON A.database_name = B.name 
				AND A.type = 'D' 
				OR A.type = 'I'  
				OR A.type = 'L'
                WHERE B.name NOT IN ('Tempdb','model')

                GROUP BY B.name, A.type
				ORDER BY B.name

               -----------Return values
			/*	SELECT * FROM ##LastBackup
				WHERE DaysSinceLastBackup >6 AND TYPE = 'D'
				OR    DaysSinceLastBackup >1 AND TYPE = 'I'
				OR    DaysSinceLastBackup >1 AND TYPE = 'L'
			*/	
  ----------------------------------------------------------------------------------------
  	IF NOT EXISTS ( select 1 from ##LastBackup )
BEGIN
 PRINT 'empty table... '  
END
ELSE
EXEC msdb.dbo.sp_send_dbmail
    @profile_name = 'newemailprofile',
    @recipients = 'sqldb.support@baesystems.com;adrian.sleigh@baesystems.com',  
    @body = 'SQL Missing Backup Issue',
    @query = 'SET NOCOUNT ON PRINT ''Missing Backups on SLKBRHSQLISCN01\ESECURITY''
          SELECT * FROM ##LastBackup
				WHERE DaysSinceLastBackup >=6 AND TYPE = ''D''
				OR    DaysSinceLastBackup >=1 AND TYPE = ''I''
				OR    DaysSinceLastBackup >=1 AND TYPE = ''L'' ',
    
	@subject = 'ALERTS- SLKBRHSQLISCN01\ESECURITY MISSING BACKUP ISSUES' ,
	@attach_query_result_as_file = 1,
	@query_attachment_filename = 'MissingBackupIssue.txt';  
PRINT 'Missing Backup Issue '
------------------------------------------------------------
GO

USE [SQL_Monitoring]
GO

/****** Object:  StoredProcedure [dbo].[sp_alert_drvspace]    Script Date: 1/10/2023 2:59:33 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Adrian Sleigh
-- Create date: 2022/03/21 V1.0
-- Item:	sp_alert_drvspace alerts space less than 20% free. Run job every 15 mins
-- Description Part of suite of scripts for monitoring
-- =============================================
CREATE PROCEDURE [dbo].[sp_alert_drvspace]
AS
	IF OBJECT_ID(N'tempdb..##drvspace') IS NOT NULL
BEGIN
DROP TABLE ##drvspace
END

CREATE TABLE ##drvspace(ran_date smalldatetime ,drive varchar(4), totalspacegb float, freespacegb float, pctfree float )
INSERT INTO ##drvspace

SELECT  getdate() AS Ran_Date
    ,   Drive
    ,   TotalSpaceGB
    ,   FreeSpaceGB
    ,   PctFree
  FROM
    (SELECT DISTINCT
        SUBSTRING(dovs.volume_mount_point, 1, 10) AS Drive
    ,   CONVERT(INT, dovs.total_bytes / 1024.0 / 1024.0 / 1024.0) AS TotalSpaceGB
    ,   CONVERT(INT, dovs.available_bytes / 1048576.0) / 1024 AS FreeSpaceGB
    ,   CAST(ROUND(( CONVERT(FLOAT, dovs.available_bytes / 1048576.0) / CONVERT(FLOAT, dovs.total_bytes / 1024.0 /
                         1024.0) * 100 ), 2) AS NVARCHAR(50)) AS PctFree
    FROM    sys.master_files AS mf
    CROSS APPLY sys.dm_os_volume_stats(mf.database_id, mf.file_id) AS dovs) AS DE

  --	SELECT * FROM ##drvspace WHERE pctfree <=20

	IF NOT EXISTS ( SELECT 1 FROM ##drvspace WHERE pctfree <=20 )
BEGIN
 PRINT 'Empty table... no drive space issues '  
END
ELSE
EXEC msdb.dbo.sp_send_dbmail
    @profile_name = 'newemailprofile',
    @recipients = 'sqldb.support@baesystems.com;adrian.sleigh@baesystems.com',  
    @body  = 'Drive Space alert in the last 15 mins......Space less than 20% free',
    @query = 'SET NOCOUNT ON PRINT ''Recent drive space alert''
         SELECT * FROM ##drvspace WHERE pctfree <=20 AND ran_date > dateadd(mi,-15,Getdate()) ',
    @subject = 'ALERTS- SLKBRHSQLISCN01\ESECURITY RECENT DRIVE SPACE ALERT LESS THAN 20% FREE', 
	@attach_query_result_as_file = 1,
	@query_attachment_filename = 'RecentDriveSpaceAlert.txt'; 
PRINT 'Recent Drive Space Alert'
GO
USE [SQL_Monitoring]
GO

/****** Object:  StoredProcedure [dbo].[sp_alert_jobfail]    Script Date: 1/10/2023 2:59:49 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[sp_alert_jobfail]
AS
-- =============================================
-- Author:		Adrian Sleigh
-- Create date: 2022/04/20 V2.0
-- Excluded alerting job
-- Item:	job_fail alert run every 15 mins
-- Description Part of suite of scripts for monitoring
-- =============================================


IF NOT EXISTS( SELECT 1 FROM msdb.dbo.sysjobs AS j
    INNER JOIN msdb.dbo.sysjobsteps AS js ON js.job_id = j.job_id
    INNER JOIN msdb.dbo.sysjobhistory AS jh ON jh.job_id = j.job_id AND jh.step_id = js.step_id
    WHERE jh.run_status = 0 
	AND j.name <> 'alerting'
    AND MSDB.dbo.agent_datetime(jh.run_date,jh.run_time) > dateadd(mi,-15,Getdate())
	)
	BEGIN
 PRINT 'empty table... no job fails' 
 GOTO ENDIT
END
ELSE
PRINT 'FAILED AGENT JOB OCCURRED'
BEGIN
 EXEC msdb.dbo.sp_send_dbmail
    @profile_name = 'newemailprofile',
    @recipients = 'sqldb.support@baesystems.com;adrian.sleigh@baesystems.com',  
    @body = 'A FAILED AGENT JOB OCCURRED',
    @query = 'SET NOCOUNT ON PRINT ''FAILED AGENT JOB OCCURRED''
    SELECT  MSDB.dbo.agent_datetime(jh.run_date,jh.run_time) AS job_ran_time,
    SUBSTRING(j.name,1,50) AS job_name,
	js.step_id AS job_step,
	SUBSTRING(jh.message,1,180) AS error_message
     FROM msdb.dbo.sysjobs AS j
      INNER JOIN msdb.dbo.sysjobsteps AS js ON js.job_id = j.job_id
      INNER JOIN msdb.dbo.sysjobhistory AS jh ON jh.job_id = j.job_id AND jh.step_id = js.step_id
         WHERE jh.run_status = 0 
       AND MSDB.dbo.agent_datetime(jh.run_date,jh.run_time) > dateadd(mi,-15,Getdate())',
    @subject = 'ALERTS - SLKBRHSQLISCN01\ESECURITY FAILED AGENT JOB OCCURRED' ,
	@attach_query_result_as_file = 1,
	@query_attachment_filename = 'FAILED_AGENT_JOB_OCCURRED.txt';  

END

ENDIT:
PRINT 'ENDED'
GO
USE [SQL_Monitoring]
GO

/****** Object:  StoredProcedure [dbo].[sp_alert_loginfail]    Script Date: 1/10/2023 3:00:04 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Adrian Sleigh
-- Create date: 2022/03/21 V1.0
-- Item:	sp_alert_loginfail alert run every 15 mins
-- Description Part of suite of scripts for monitoring
-- =============================================
CREATE PROCEDURE [dbo].[sp_alert_loginfail]
AS

IF OBJECT_ID(N'tempdb..##LoginFail') IS NOT NULL
BEGIN
DROP TABLE ##LoginFail
END

CREATE TABLE ##LoginFail(logdate smalldatetime ,processInfo varchar(10), TextDesc Text)
INSERT INTO ##LoginFail
 EXEC sp_readerrorlog 0, 1, 'Login failed' 

IF NOT EXISTS ( select 1 from ##LoginFail )
BEGIN
 PRINT 'empty table... no failed logins'  
END
ELSE
EXEC msdb.dbo.sp_send_dbmail
    @profile_name = 'newemailprofile',
    @recipients = 'sqldb.support@baesystems.com;adrian.sleigh@baesystems.com',  
    @body  = 'Failed logins in the last 15 mins......',
    @query = 'SET NOCOUNT ON PRINT ''Recent Failed Logins''
       SELECT * FROM ##LoginFail WHERE logdate > dateadd(mi,-15,Getdate())',
    @subject = 'ALERTS- SLKBRHSQLISCN01\ESECURITY RECENT LOGIN FAILS', 
	@attach_query_result_as_file = 1,
	@query_attachment_filename = 'RecentLoginFails.txt'; 
PRINT 'Recent Login fails present'
GO

-----------------------------------------------------------------------------------------------------------



