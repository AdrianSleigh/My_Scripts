USE [SQL_Monitoring]
GO
/****** Object:  StoredProcedure [dbo].[usp_FindServerLastRebootDateTime]    Script Date: 5/16/2024 11:10:09 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =================================================================================
-- -- Create date:   16/05/24
-- Procedure Name: dbo.usp_FindServerLastRebootDateTime
-- Description:    This procedure finds the last OS reboot date and time and  
--                 last restart date and time of the SQL Server service.
-- ==================================================================================
CREATE PROCEDURE [dbo].[usp_FindServerLastRebootDateTime] 
AS
BEGIN
   DECLARE @rebootDT NVARCHAR (20)
   DECLARE @SQLServiceLastRestrartDT NVARCHAR (20)
   DECLARE @dosStmt NVARCHAR (200)
   DECLARE @dosResult TABLE (line NVARCHAR (500))
 
   SET NOCOUNT ON

    exec sp_configure 'xp_cmdshell', 1 reconfigure
 
   SET @dosStmt = 'wmic os get lastbootuptime'

 ---Temporarily allow xp_cmdshell

   INSERT INTO @dosResult EXEC sys.xp_cmdShell @dosStmt
 
   SELECT @rebootDT = CONCAT (
         SUBSTRING (line, 1, 4),'-',
         SUBSTRING (line, 5, 2),'-',
         SUBSTRING (line, 7, 2),' ',
         SUBSTRING (line, 9, 2),':',
         SUBSTRING (line, 11, 2),':',
         SUBSTRING (line, 13, 2)
         )
   FROM @dosResult
   WHERE CHARINDEX ('.', line, 1) > 0
 
   SELECT @SQLServiceLastRestrartDT = CONVERT(NVARCHAR (11), create_date, 23) + ' ' + CONVERT(VARCHAR (8), create_date, 108)
   FROM sys.databases
   WHERE rtrim(ltrim(upper([name]))) = 'TEMPDB'
   
   SELECT @rebootDT as OSServerRebootDateTime, @SQLServiceLastRestrartDT as SQLServiceRestartDateTime
   
   SET NOCOUNT OFF

    ---Disable xp_cmdshell
   exec sp_configure 'xp_cmdshell', 0 reconfigure
END