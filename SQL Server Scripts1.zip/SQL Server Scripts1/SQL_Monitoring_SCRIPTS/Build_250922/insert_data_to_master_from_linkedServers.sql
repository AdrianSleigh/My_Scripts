 INSERT INTO [SLKBRHSQLDSCN02\DEVELOPMENT].[Master_SQL_Monitoring].[dbo].[M_BACKUPS]
(
[SQL_Instance],[Ran_Date],[HA_Primary],[Database_Name],[DaysSinceLastBackup],[LastBackupDate],[BackupType]
)
 
 SELECT Serverproperty('servername'),[Ran_Date],[HA_Primary],[Database_Name],[DaysSinceLastBackup],[LastBackupDate],[BackupType] FROM [SLKBRHSMDB01\LYNC2013].[SQL_Monitoring].[dbo].[BACKUPS]
 SELECT @@Servername,[Ran_Date],[HA_Primary],[Database_Name],[DaysSinceLastBackup],[LastBackupDate],[BackupType] FROM [SLKBRHSQLBSCN01\APPS_INST].[SQL_Monitoring].[dbo].[BACKUPS]
 SELECT @@Servername,[Ran_Date],[HA_Primary],[Database_Name],[DaysSinceLastBackup],[LastBackupDate],[BackupType] FROM [SLKBRHSQLBSCN01\PRODMVM].[SQL_Monitoring].[dbo].[BACKUPS]
 SELECT @@Servername,[Ran_Date],[HA_Primary],[Database_Name],[DaysSinceLastBackup],[LastBackupDate],[BackupType] FROM [SLKBRHSQLBSCN01\WEBAPPS].[SQL_Monitoring].[dbo].[BACKUPS]
 SELECT @@Servername,[Ran_Date],[HA_Primary],[Database_Name],[DaysSinceLastBackup],[LastBackupDate],[BackupType] FROM [SLKBRHSQLBSCN01\PRODCONFIGSERV].[SQL_Monitoring].[dbo].[BACKUPS]
 SELECT @@Servername,[Ran_Date],[HA_Primary],[Database_Name],[DaysSinceLastBackup],[LastBackupDate],[BackupType] FROM [SLKBRHSQLBSCN01\PRODCONTENT].[SQL_Monitoring].[dbo].[BACKUPS]
 SELECT @@Servername,[Ran_Date],[HA_Primary],[Database_Name],[DaysSinceLastBackup],[LastBackupDate],[BackupType] FROM [SLKBRHSQLBSCN01\PRODRECORDS].[SQL_Monitoring].[dbo].[BACKUPS]
 SELECT @@Servername,[Ran_Date],[HA_Primary],[Database_Name],[DaysSinceLastBackup],[LastBackupDate],[BackupType] FROM [SLKBRHSQLBSCN01\PRODSEARCH].[SQL_Monitoring].[dbo].[BACKUPS]
 SELECT @@Servername,[Ran_Date],[HA_Primary],[Database_Name],[DaysSinceLastBackup],[LastBackupDate],[BackupType] FROM [SLKBRHSQLBSCN01\PRODUCTION].[SQL_Monitoring].[dbo].[BACKUPS]
 SELECT @@Servername,[Ran_Date],[HA_Primary],[Database_Name],[DaysSinceLastBackup],[LastBackupDate],[BackupType] FROM [SLKBRHSQLBSCN02\APPS_INST].[SQL_Monitoring].[dbo].[BACKUPS]
 SELECT @@Servername,[Ran_Date],[HA_Primary],[Database_Name],[DaysSinceLastBackup],[LastBackupDate],[BackupType] FROM [SLKBRHSQLBSCN02\WEBAPPS].[SQL_Monitoring].[dbo].[BACKUPS]
 SELECT @@Servername,[Ran_Date],[HA_Primary],[Database_Name],[DaysSinceLastBackup],[LastBackupDate],[BackupType] FROM [SLKBRHSQLBSCN02\PRODCONFIGSERV].[SQL_Monitoring].[dbo].[BACKUPS]
 SELECT @@Servername,[Ran_Date],[HA_Primary],[Database_Name],[DaysSinceLastBackup],[LastBackupDate],[BackupType] FROM [SLKBRHSQLBSCN02\PRODCONTENT].[SQL_Monitoring].[dbo].[BACKUPS]
 SELECT @@Servername,[Ran_Date],[HA_Primary],[Database_Name],[DaysSinceLastBackup],[LastBackupDate],[BackupType] FROM [SLKBRHSQLBSCN02\PRODRECORDS].[SQL_Monitoring].[dbo].[BACKUPS]
 SELECT @@Servername,[Ran_Date],[HA_Primary],[Database_Name],[DaysSinceLastBackup],[LastBackupDate],[BackupType] FROM [SLKBRHSQLBSCN02\PRODSEARCH].[SQL_Monitoring].[dbo].[BACKUPS]
 SELECT @@Servername,[Ran_Date],[HA_Primary],[Database_Name],[DaysSinceLastBackup],[LastBackupDate],[BackupType] FROM [SLKBRHSQLBSCN02\PRODUCTION].[SQL_Monitoring].[dbo].[BACKUPS]
 SELECT @@Servername,[Ran_Date],[HA_Primary],[Database_Name],[DaysSinceLastBackup],[LastBackupDate],[BackupType] FROM [SLKBRHSQLDSCN01\DBTESTING].[SQL_Monitoring].[dbo].[BACKUPS]
 SELECT @@Servername,[Ran_Date],[HA_Primary],[Database_Name],[DaysSinceLastBackup],[LastBackupDate],[BackupType] FROM [SLKBRHSQLDSCN01\PRESHAREPOINT].[SQL_Monitoring].[dbo].[BACKUPS]
 SELECT @@Servername,[Ran_Date],[HA_Primary],[Database_Name],[DaysSinceLastBackup],[LastBackupDate],[BackupType] FROM [SLKBRHSQLDSCN02\DEVELOPMENT].[SQL_Monitoring].[dbo].[BACKUPS]
 SELECT @@Servername,[Ran_Date],[HA_Primary],[Database_Name],[DaysSinceLastBackup],[LastBackupDate],[BackupType] FROM [SLKBRHSQLISCN01\ESECURITY].[SQL_Monitoring].[dbo].[BACKUPS]
 SELECT @@Servername,[Ran_Date],[HA_Primary],[Database_Name],[DaysSinceLastBackup],[LastBackupDate],[BackupType] FROM [SLKBRHSQLISCN01\ISREPORTING].[SQL_Monitoring].[dbo].[BACKUPS]
 SELECT @@Servername,[Ran_Date],[HA_Primary],[Database_Name],[DaysSinceLastBackup],[LastBackupDate],[BackupType] FROM [SLKBRHSQLISCN01\SCCM].[SQL_Monitoring].[dbo].[BACKUPS]
 SELECT @@Servername,[Ran_Date],[HA_Primary],[Database_Name],[DaysSinceLastBackup],[LastBackupDate],[BackupType] FROM [SLKBRHSQLISCN01\SCOM].[SQL_Monitoring].[dbo].[BACKUPS]
 SELECT @@Servername,[Ran_Date],[HA_Primary],[Database_Name],[DaysSinceLastBackup],[LastBackupDate],[BackupType] FROM [SLKBRHSQLISCN02\ISREPORTING].[SQL_Monitoring].[dbo].[BACKUPS]
 SELECT @@Servername,[Ran_Date],[HA_Primary],[Database_Name],[DaysSinceLastBackup],[LastBackupDate],[BackupType] FROM [SLKBRHSQLISCN02\SCCM].[SQL_Monitoring].[dbo].[BACKUPS]
 SELECT @@Servername,[Ran_Date],[HA_Primary],[Database_Name],[DaysSinceLastBackup],[LastBackupDate],[BackupType] FROM [SLKBRHSQLISCN02\SCOM].[SQL_Monitoring].[dbo].[BACKUPS]
 SELECT @@Servername,[Ran_Date],[HA_Primary],[Database_Name],[DaysSinceLastBackup],[LastBackupDate],[BackupType] FROM [SLKBRHSQ04\ESECURITY].[SQL_Monitoring].[dbo].[BACKUPS]
 SELECT @@Servername,[Ran_Date],[HA_Primary],[Database_Name],[DaysSinceLastBackup],[LastBackupDate],[BackupType] FROM [SLKBRHSQT12\CONFIGSERV].[SQL_Monitoring].[dbo].[BACKUPS]
 SELECT @@Servername,[Ran_Date],[HA_Primary],[Database_Name],[DaysSinceLastBackup],[LastBackupDate],[BackupType] FROM [SLKBRHSQT12\CONTENT].[SQL_Monitoring].[dbo].[BACKUPS]


  
 ---Inserts data from all linkedservers to M_Backups on  [SLKBRHSQLDSCN02\DEVELOPMENT]
 ---Adrian Sleigh V1.0 19/02/23
 ----------------------------------------------------------------------------------------
 
DECLARE @num int =1, @count int, @serv Varchar (120)

------------------------------------------
CREATE TABLE ##Instance
(
[id] [INT] IDENTITY(1,1) NOT NULL, [name] VARCHAR (120)
)
--------------------------------------------
INSERT INTO ##Instance
SELECT [name]
FROM master.sys.servers 
WHERE is_linked = 1
 -------------------------------------------
DECLARE @num int = 1,@count int, @serv Varchar (120)
 SET @count = 
 (SELECT COUNT (*) FROM ##Instance)

 WHILE @num <= @count
 BEGIN
    SET @serv =
    (SELECT [name] FROM ##Instance WHERE [id] = @num)


    PRINT @serv
    PRINT @num

INSERT INTO [SLKBRHSQLDSCN02\DEVELOPMENT].[Master_SQL_Monitoring].[dbo].[M_BACKUPS]
(
[SQL_Instance],[Ran_Date],[HA_Primary],[Database_Name],[DaysSinceLastBackup],[LastBackupDate],[BackupType]
)
 
 SELECT @serv,[Ran_Date],[HA_Primary],[Database_Name],[DaysSinceLastBackup],[LastBackupDate],[BackupType] FROM [SLKBRHSMDB01\LYNC2013].[SQL_Monitoring].[dbo].[BACKUPS]
	
         SET @num=@num + 1
 END
 ---------------------------------------------------------------------------------------------------------
  