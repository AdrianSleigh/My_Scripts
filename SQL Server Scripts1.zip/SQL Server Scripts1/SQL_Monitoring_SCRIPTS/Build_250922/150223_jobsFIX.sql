USE [msdb]
GO
/****** Object:  Step [Login_sync]    Script Date: 2/15/2023 2:24:10 PM ******/
EXEC msdb.dbo.sp_delete_jobstep @job_id=N'ef65a60a-b1ea-4add-9fef-49b5a1cf511f', @step_id=13
GO
USE [msdb]
GO
/****** Object:  Step [Last_Used_DB]    Script Date: 2/15/2023 2:24:10 PM ******/
EXEC msdb.dbo.sp_delete_jobstep @job_id=N'ef65a60a-b1ea-4add-9fef-49b5a1cf511f', @step_id=12
GO
USE [msdb]
GO
/****** Object:  Step [Memory Usage]    Script Date: 2/15/2023 2:24:10 PM ******/
EXEC msdb.dbo.sp_delete_jobstep @job_id=N'ef65a60a-b1ea-4add-9fef-49b5a1cf511f', @step_id=11
GO
USE [msdb]
GO
/****** Object:  Step [CPU Details]    Script Date: 2/15/2023 2:24:10 PM ******/
EXEC msdb.dbo.sp_delete_jobstep @job_id=N'ef65a60a-b1ea-4add-9fef-49b5a1cf511f', @step_id=10
GO
USE [msdb]
GO
/****** Object:  Step [Database Activity]    Script Date: 2/15/2023 2:24:10 PM ******/
EXEC msdb.dbo.sp_delete_jobstep @job_id=N'ef65a60a-b1ea-4add-9fef-49b5a1cf511f', @step_id=9
GO
USE [msdb]
GO
/****** Object:  Step [Database Sizes]    Script Date: 2/15/2023 2:24:10 PM ******/
EXEC msdb.dbo.sp_delete_jobstep @job_id=N'ef65a60a-b1ea-4add-9fef-49b5a1cf511f', @step_id=8
GO
USE [msdb]
GO
/****** Object:  Step [Fragmentation]    Script Date: 2/15/2023 2:24:10 PM ******/
EXEC msdb.dbo.sp_delete_jobstep @job_id=N'ef65a60a-b1ea-4add-9fef-49b5a1cf511f', @step_id=7
GO
USE [msdb]
GO
/****** Object:  Step [Worst Queries]    Script Date: 2/15/2023 2:24:10 PM ******/
EXEC msdb.dbo.sp_delete_jobstep @job_id=N'ef65a60a-b1ea-4add-9fef-49b5a1cf511f', @step_id=6
GO
USE [msdb]
GO
/****** Object:  Step [Drive Space Free]    Script Date: 2/15/2023 2:24:10 PM ******/
EXEC msdb.dbo.sp_delete_jobstep @job_id=N'ef65a60a-b1ea-4add-9fef-49b5a1cf511f', @step_id=5
GO
USE [msdb]
GO
/****** Object:  Step [Failed Logins 7 Days]    Script Date: 2/15/2023 2:24:10 PM ******/
EXEC msdb.dbo.sp_delete_jobstep @job_id=N'ef65a60a-b1ea-4add-9fef-49b5a1cf511f', @step_id=4
GO
USE [msdb]
GO
/****** Object:  Step [Last Backup]    Script Date: 2/15/2023 2:24:10 PM ******/
EXEC msdb.dbo.sp_delete_jobstep @job_id=N'ef65a60a-b1ea-4add-9fef-49b5a1cf511f', @step_id=3
GO
USE [msdb]
GO
/****** Object:  Step [Failed Jobs]    Script Date: 2/15/2023 2:24:10 PM ******/
EXEC msdb.dbo.sp_delete_jobstep @job_id=N'ef65a60a-b1ea-4add-9fef-49b5a1cf511f', @step_id=2
GO
USE [msdb]
GO
/****** Object:  Step [Age out Data]    Script Date: 2/15/2023 2:24:10 PM ******/
EXEC msdb.dbo.sp_delete_jobstep @job_id=N'ef65a60a-b1ea-4add-9fef-49b5a1cf511f', @step_id=1
GO
USE [msdb]
GO
EXEC msdb.dbo.sp_add_jobstep @job_id=N'ef65a60a-b1ea-4add-9fef-49b5a1cf511f', @step_name=N'Age out Data', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_fail_action=2, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'-- =============================================
-- Author:		Adrian Sleigh
-- Create date: 2022/03/10 V1.0
-- Item: Housekeeping for monitoring delete old data
-- Description Part of suite of scripts for monitoring
-- =============================================

DELETE  FROM [SQL_Monitoring].[dbo].[CPU_USAGE]
  WHERE SYSTEM_IDLE >= 98

  DELETE FROM [SQL_Monitoring].[dbo].[DB_SIZES]
  WHERE Ran_date <= getdate() -180

  DELETE  FROM [SQL_Monitoring].[dbo].[DRIVE_SPACE_FREE]
  WHERE Ran_date <= getdate() -180

DELETE FROM [SQL_Monitoring].[dbo].[BLOCKING]
  WHERE Ran_date <= getdate() -60

DELETE FROM [SQL_Monitoring].[dbo].[CONNECTION_MONITOR]
  WHERE latestLogin <= getdate() -60

DELETE FROM [SQL_Monitoring].[dbo].[CPU_DETAILS]
  WHERE Ran_date <= getdate() -60

DELETE FROM [SQL_Monitoring].[dbo].[DB_ACTIVITY]
  WHERE collected_Date <= getdate() -60

DELETE FROM [SQL_Monitoring].[dbo].[FRAGMENTATION]
  WHERE Ran_date <= getdate() -60

DELETE FROM [SQL_Monitoring].[dbo].[JOB_FAILS]
  WHERE job_ran <= getdate() -60

DELETE FROM [SQL_Monitoring].[dbo].[LOGINS_ISSUE]
  WHERE Ran_date <= getdate() -60

DELETE FROM [SQL_Monitoring].[dbo].[PLE]
  WHERE Timeran <= getdate() -60

DELETE FROM [SQL_Monitoring].[dbo].[WORST_QUERIES]
	WHERE Collected_time <= getdate() -60
----------------------------------------------------------------



', 
		@database_name=N'SQL_Monitoring', 
		@flags=0
GO
USE [msdb]
GO
EXEC msdb.dbo.sp_add_jobstep @job_id=N'ef65a60a-b1ea-4add-9fef-49b5a1cf511f', @step_name=N'Failed Jobs', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_fail_action=2, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC sp_failed_jobs 7', 
		@database_name=N'SQL_Monitoring', 
		@flags=0
GO
USE [msdb]
GO
EXEC msdb.dbo.sp_add_jobstep @job_id=N'ef65a60a-b1ea-4add-9fef-49b5a1cf511f', @step_name=N'Last Backup', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_fail_action=2, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC sp_last_backup

', 
		@database_name=N'SQL_Monitoring', 
		@flags=0
GO
USE [msdb]
GO
EXEC msdb.dbo.sp_add_jobstep @job_id=N'ef65a60a-b1ea-4add-9fef-49b5a1cf511f', @step_name=N'Failed Logins 7 Days', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_fail_action=2, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC sp_get_failed_login_list_last_week', 
		@database_name=N'SQL_Monitoring', 
		@flags=0
GO
USE [msdb]
GO
EXEC msdb.dbo.sp_add_jobstep @job_id=N'ef65a60a-b1ea-4add-9fef-49b5a1cf511f', @step_name=N'Drive Space Free', 
		@step_id=5, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_fail_action=2, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC sp_drive_space_free', 
		@database_name=N'SQL_Monitoring', 
		@flags=0
GO
USE [msdb]
GO
EXEC msdb.dbo.sp_add_jobstep @job_id=N'ef65a60a-b1ea-4add-9fef-49b5a1cf511f', @step_name=N'Worst Queries', 
		@step_id=6, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_fail_action=2, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'--FROM SQL_MONITORING DATABASE to populate WORST_QUERIES
--job required to run daily
--Adrian Sleigh 06/02/22
----------------------------------------------------------------------

EXEC [dbo].[SP_run_query_across_databases]''

INSERT INTO SQL_Monitoring.dbo.WORST_QUERIES (database_name,collected_time,object_name,max_logical_reads,max_logical_writes,
total_RW,max_elapsed_time_MS,execution_cost,last_execution_time,execution_count,object_text)

(SELECT TOP 10 
db_name() as database_name,
getdate()as collected_time,
obj.name, 
max_logical_reads, 
max_logical_writes,
max_logical_reads + max_logical_writes as total_RW,
max_elapsed_time,
max_logical_reads + max_logical_writes/execution_count as execution_cost,
last_execution_time,
execution_count,[text]

FROM sys.dm_exec_query_stats a
CROSS APPLY sys.dm_exec_sql_text(sql_handle) hnd
INNER JOIN sys.sysobjects obj on hnd.objectid = obj.id)
ORDER BY max_elapsed_time DESC
''
---END', 
		@database_name=N'master', 
		@flags=0
GO
USE [msdb]
GO
EXEC msdb.dbo.sp_add_jobstep @job_id=N'ef65a60a-b1ea-4add-9fef-49b5a1cf511f', @step_name=N'Fragmentation', 
		@step_id=7, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_fail_action=2, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC sp_fragmentation', 
		@database_name=N'SQL_Monitoring', 
		@flags=0
GO
USE [msdb]
GO
EXEC msdb.dbo.sp_add_jobstep @job_id=N'ef65a60a-b1ea-4add-9fef-49b5a1cf511f', @step_name=N'Database Sizes', 
		@step_id=8, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_fail_action=2, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC sp_db_Sizes', 
		@database_name=N'SQL_Monitoring', 
		@flags=0
GO
USE [msdb]
GO
EXEC msdb.dbo.sp_add_jobstep @job_id=N'ef65a60a-b1ea-4add-9fef-49b5a1cf511f', @step_name=N'Database Activity', 
		@step_id=9, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_fail_action=2, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC sp_db_Activity', 
		@database_name=N'SQL_Monitoring', 
		@flags=0
GO
USE [msdb]
GO
EXEC msdb.dbo.sp_add_jobstep @job_id=N'ef65a60a-b1ea-4add-9fef-49b5a1cf511f', @step_name=N'CPU Details', 
		@step_id=10, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_fail_action=2, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC sp_cpu_details', 
		@database_name=N'SQL_Monitoring', 
		@flags=0
GO
USE [msdb]
GO
EXEC msdb.dbo.sp_add_jobstep @job_id=N'ef65a60a-b1ea-4add-9fef-49b5a1cf511f', @step_name=N'Memory Usage', 
		@step_id=11, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_fail_action=2, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC sp_memory_usage', 
		@database_name=N'SQL_Monitoring', 
		@flags=0
GO
USE [msdb]
GO
EXEC msdb.dbo.sp_add_jobstep @job_id=N'ef65a60a-b1ea-4add-9fef-49b5a1cf511f', @step_name=N'DatabaseGrowth', 
		@step_id=12, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_fail_action=2, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'TRUNCATE TABLE [dbo].[DB_GROWTH]
GO
INSERT INTO [dbo].[DB_GROWTH]
(
[Ran_Date],[DatabaseName],[YearMonth],[MinSize],[MaxSize],[AvgSize],[Growth]
)
EXEC [dbo].[sp_db_growth]

--------------------------------------------------------------------------------------------
TRUNCATE TABLE [dbo].[DB_GROWTH_12]
GO
INSERT INTO [dbo].[DB_GROWTH_12]
(
[Ran_Date],[DatabaseName],[0],[-1],[-2],[-3],[-4],[-5],[-6],[-7],[-8],[-9],[-10],[-11],[-12]
)
EXEC [dbo].[sp_db_growth_12]', 
		@database_name=N'SQL_Monitoring', 
		@flags=0
GO
USE [msdb]
GO
EXEC msdb.dbo.sp_add_jobstep @job_id=N'ef65a60a-b1ea-4add-9fef-49b5a1cf511f', @step_name=N'Last_Used_DB', 
		@step_id=13, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_fail_action=2, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'-----INSTANCE LEVEL LAST USED OBJECTS
----LAST USED DATABASE
----------------------------------------------------------------------------
INSERT INTO [dbo].[LAST_USED_DB]
([Last_Restart],[DbName],[Last_User_Seek],[Last_User_Scan],[Last_User_Lookup],[Last_User_Update])

SELECT 
(SELECT sqlserver_start_time FROM sys.dm_os_sys_info)As Last_SQL_Restart, 
d.name,
last_user_seek = MAX(last_user_seek),
last_user_scan = MAX(last_user_scan),
last_user_lookup = MAX(last_user_lookup),
last_user_update = MAX(last_user_update)
FROM sys.dm_db_index_usage_stats AS i
JOIN sys.databases AS d ON i.database_id=d.database_id
WHERE d.name NOT IN (''master'',''msdb'',''tempdb'')
GROUP BY d.name', 
		@database_name=N'SQL_Monitoring', 
		@flags=0
GO
USE [msdb]
GO
EXEC msdb.dbo.sp_add_jobstep @job_id=N'ef65a60a-b1ea-4add-9fef-49b5a1cf511f', @step_name=N'Login_sync', 
		@step_id=14, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_fail_action=2, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'-- =============================================
-- Author:		Adrian Sleigh
-- Create date: 2022/03/13 V2.0
-- Item:	Login_sync
-- Description Part of suite of scripts for monitoring added mail
-- Inserts non duplicate logins to table [SQL_Monitoring].dbo.LOGINS_ISSUE 
--Sends email if logins are not in sync to sqldb.support@baesystems.com
-- =============================================

USE SQL_Monitoring

INSERT INTO LOGINS_ISSUE
([ran_date],[primary_instance],[secondary_instance])

SELECT getdate() AS ran_date,
       A.name AS PRIMARY_INSTANCE, 
       B.name AS SECONDARY_INSTANCE
FROM            [SLKBRHSQLDSCN02\DEVELOPMENT].[master].[dbo].[syslogins] A
FULL OUTER JOIN [SLKBRHSQLDSCN01\DEVELOPMENT].[master].[dbo].[syslogins] B
ON A.name =B.name
WHERE A.name NOT LIKE ''##%''
  AND A.name NOT LIKE ''NT%''
  AND B.name IS NULL
  OR A.name IS NULL

  IF NOT EXISTS ( select 1 from [SQL_Monitoring].dbo.LOGINS_ISSUE )
BEGIN
 PRINT ''empty table... all account in sync''  
END
ELSE
EXEC msdb.dbo.sp_send_dbmail
    @profile_name = ''newemailprofile'',
    @recipients = ''sqldb.support@baesystems.com;adrian.sleigh@baesystems.com'',  
    @body = ''Logins on Primary Instance are not the same as Secondary'',
    @query = ''SET NOCOUNT ON PRINT ''''Logins on Primary Instance are not the same as Secondary''''
SELECT SUBSTRING(@@servername,1,40) AS PrimarySQLInstance,
       SUBSTRING(primary_instance,1,40) AS primary_login,
	   SUBSTRING(secondary_instance,1,40)  AS secondary_login
	FROM [SQL_Monitoring].dbo.LOGINS_ISSUE'',
    @subject = ''ALERTS - SLKBRHSQLDSCN02\DEVELOPMENT-SLKBRHSQLDSCN01\DEVELOPMENT LOGINS OUT OF SYNC'' ,
	@attach_query_result_as_file = 1,
	@query_attachment_filename = ''Login_Sync_error.txt'';;  
PRINT ''accounts are not in sync''
GO', 
		@database_name=N'SQL_Monitoring', 
		@flags=0
GO
