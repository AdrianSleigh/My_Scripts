---CREATE LINKED SERVER FOR REPORTING
---------------------------------------------

USE [master]
GO
CREATE LOGIN [Link_SVR] WITH PASSWORD=N'2s%fgGn90X$ssM33!!'
GO
USE [SQL_Monitoring]
GO
CREATE USER [Link_SVR] FOR LOGIN [Link_SVR]
GO
USE [SQL_Monitoring]
GO
ALTER ROLE [db_datareader] ADD MEMBER [Link_SVR]
GO