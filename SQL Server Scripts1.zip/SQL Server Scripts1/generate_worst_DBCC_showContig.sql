----GENERATES SQL FOR THE TOP FRAGMENTED TABLES
----------------------------------------------
SELECT TOP 10 
'DBCC SHOWCONTIG(' + CAST(id AS NVARCHAR(20)) + ')' 
+ CHAR(10) + 
'PRINT '' ''' + CHAR(10) 
FROM 
sysindexes 
WHERE 
indid = 1 or 
indid = 0 
ORDER BY rows DESC
--------------------------------------