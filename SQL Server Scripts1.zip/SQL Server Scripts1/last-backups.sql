----------------------------------------------
----------------------------------------------
PRINT 'LAST SUCESSFUL BACKUPS '
SELECT SUBSTRING(B.name,1,30) as Database_Name, ISNULL(STR(ABS(DATEDIFF(day, GetDate(), 
                MAX(Backup_finish_date)))), 'NEVER') as DaysSinceLastBackup,
                ISNULL(Convert(char(10), MAX(backup_finish_date), 101), 'NEVER') as LastBackupDate,
				A.type as 'TYPE'
                FROM master.dbo.sysdatabases B LEFT OUTER JOIN msdb.dbo.backupset A 
                ON A.database_name = B.name 
				AND A.type = 'D' 
                                   OR A.type = 'I' 
				   OR A.type = 'T'  
                WHERE b.name NOT IN ('Tempdb','model','msdb','master')
                GROUP BY B.Name, A.type
				 ORDER BY B.name
                
            -----detailed view
            ------LAST 2 WEEKS HISTORY-----------------------------
		USE MSDB
		 SELECT 
                [database_name]as 'DB',[backup_start_date] as ' backup start',
                [backup_finish_date]as 'backup finish',
                [type],[backup_size]as 'Size in Bytes' ,[recovery_model] as 'Model',
                [is_snapshot]as 'Snapshot',[is_copy_only],
                [name]as 'backup utility',[user_name]as 'utility account'
           FROM backupset 
		WHERE backup_finish_date >= DATEADD(week, -2, GETDATE())
	--	AND database_name IN ('SharePoint2013Prod_CeC_Profile')
		 ORDER BY database_name ,backup_start_date DESC