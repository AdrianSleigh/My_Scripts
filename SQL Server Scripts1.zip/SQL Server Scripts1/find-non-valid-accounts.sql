---VALIDATES LOGINS AND HIGHLIGHTS  ACCOUNTS NO LONGER REQUIRED----
--CREATES DROP TSQL 08/05/19
-------------------------------------------------------
IF (OBJECT_ID('tempdb..#invalidlogins') IS NOT NULL)
 BEGIN
 DROP TABLE #invalidlogins
 END 

CREATE TABLE #invalidlogins(
  ACCTSID VARBINARY(100)
 , NTLOGIN SYSNAME)

INSERT INTO #invalidlogins
 EXEC sys.sp_validatelogins

SELECT NTLOGIN FROM #invalidlogins
 order by 1
 --------------------

--GENERATES DROP SCRIPT FOR ACCOUNTS THAT ARE NO LNGER VALID
------------------------------------------------------------

declare @user sysname
declare @domain varchar(100)
 
set @domain = 'ourcheshire'
 
declare recscan cursor for
select name from sys.server_principals
where type IN ('U','G') and name like @domain+'%'
 
open recscan 
fetch next from recscan into @user
 
while @@fetch_status = 0
begin
    begin try
        exec xp_logininfo @user
    end try
    begin catch
        --Error on xproc because login doesn't exist
        print 'drop login ['+convert(varchar(100),@user+']')
    end catch
 
    fetch next from recscan into @user
end
 
close recscan
deallocate recscan
-------------------------------------------------------------