--Get service account info
--------------------------------------------------
DECLARE @DatabaseEngineAccount VARCHAR(100) 
DECLARE @SQLAgentAccount VARCHAR(100) 

EXECUTE Xp_instance_regread 
  @rootkey = N'HKEY_LOCAL_MACHINE', 
  @key = N'SYSTEM\CurrentControlSet\Services\MSSQLServer', 
  @value_name = N'ObjectName', 
  @value = @DatabaseEngineAccount output 

EXECUTE Xp_instance_regread 
  @rootkey = N'HKEY_LOCAL_MACHINE', 
  @key = N'SYSTEM\CurrentControlSet\Services\SQLServerAgent', 
  @value_name = N'ObjectName', 
  @value = @SQLAgentAccount output 

SELECT @@SERVERNAME           AS SQLInstance, 
       @DatabaseEngineAccount AS DatabaseEngineServiceAccount, 
       @SQLAgentAccount       AS SQLAgentServiceAccount