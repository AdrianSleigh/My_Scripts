--version_store_info TEMPDB
----
--WHILE 1=1

BEGIN
select getdate()
DECLARE @runtime datetime
SET @runtime = GETDATE()

PRINT '� sys.dm_db_file_space_used'

select CONVERT (varchar(30), @runtime, 121) AS runtime, SUM (user_object_reserved_page_count)*8 as usr_obj_kb,

SUM (internal_object_reserved_page_count)*8 as internal_obj_kb,
SUM (version_store_reserved_page_count)*8  as version_store_kb,
SUM (unallocated_extent_page_count)*8 as freespace_kb,
SUM (mixed_extent_page_count)*8 as mixedextent_kb

FROM sys.dm_db_file_space_usage

RAISERROR ('', 0, 1) WITH NOWAIT

PRINT ' � Output of active transactions which are using version store'

select CONVERT (varchar(30), @runtime, 121) AS runtime,a.*,b.kpid,b.blocked,b.lastwaittype,b.waitresource,b.dbid,b.cpu,b.physical_io,b.memusage,b.login_time,b.last_batch,b.open_tran,b.status,b.hostname,b.program_name,b.cmd,b.loginame,request_id

from sys.dm_tran_active_snapshot_database_transactions a

inner join sys.sysprocesses b

on a.session_id = b.spid

RAISERROR ('', 0, 1) WITH NOWAIT

 

PRINT ' � Input buffer of SPIDs identified above Output of active transactions which are using version store'

select CONVERT (varchar(30), @runtime, 121) AS runtime,b.spid,c.*
from sys.dm_tran_active_snapshot_database_transactions a
inner join sys.sysprocesses b
on a.session_id = b.spid

cross apply sys.dm_exec_sql_text(sql_handle) c

RAISERROR ('', 0, 1) WITH NOWAIT

PRINT ' � Open cursors'

select * from sys.dm_exec_cursors(0) a

cross apply sys.dm_exec_sql_text(sql_handle)
WHERE DATEDIFF(hh, a.creation_time, GETDATE()) > 1;
RAISERROR ('', 0, 1) WITH NOWAIT
 
--WAITFOR DELAY '00:00:15' 

END

GO