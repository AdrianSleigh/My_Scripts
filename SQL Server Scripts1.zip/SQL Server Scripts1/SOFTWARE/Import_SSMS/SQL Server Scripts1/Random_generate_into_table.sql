--TEST LOAD INTO TABLE
--Adrian Sleigh 30/09/21

/****** Object:  Table [dbo].[random_table]    Script Date: 30/09/2021 09:53:11 ******/
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[random_table]') AND type in (N'U'))
SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[random_table](
	[id] [int] NULL,
	[mypassword] [varchar](500) NULL
) ON [PRIMARY]
GO
USE TEST
GO
with randowvalues
    as(
       select 1 id, CONVERT(varchar(500), CRYPT_GEN_RANDOM(500)) as mypassword
        union  all
        select id + 1,  CONVERT(varchar(500), CRYPT_GEN_RANDOM(500)) as mypassword
        from randowvalues
        where 
          id < 10000
      )
 
     select * INTO random_table
    from randowvalues
    OPTION(MAXRECURSION 0)

----------------------------------------------------------------
	USE TEST
	GO
	DECLARE @Counter INT 
SET @Counter=1
  WHILE ( @Counter <= 100)
	BEGIN
	
	with randowvalues
    as(
       select 1 id, CONVERT(varchar(500), CRYPT_GEN_RANDOM(500)) as mypassword
        union  all
        select id + 1,  CONVERT(varchar(500), CRYPT_GEN_RANDOM(500)) as mypassword
        from randowvalues
        where 
          id < 1000000
      )
 
     INSERT INTO random_table (id,mypassword)
	 SELECT * FROM
     randowvalues
    OPTION(MAXRECURSION 0)
	 SET @Counter  = @Counter  + 1
END
   	SELECT COUNT (*) FROM random_table
	
 
