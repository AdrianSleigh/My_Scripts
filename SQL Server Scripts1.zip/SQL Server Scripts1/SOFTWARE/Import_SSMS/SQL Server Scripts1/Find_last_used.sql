-------FIND LAST USED IN DATABASE
select
    object_name(object_id) as OBJ_NAME, *
from
    sys.dm_db_index_usage_stats
where
    database_id = db_id(db_name())
Order by
    dm_db_index_usage_stats.last_user_update desc


SELECT name, modify_date from sys.objects where type ='U' order by modify_date desc