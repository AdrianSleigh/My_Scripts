USE [msdb]
GO

/****** Object:  Job [AUTO_ENABLE_JOBS]    Script Date: 09/12/2021 14:52:21 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 09/12/2021 14:52:21 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'AUTO_ENABLE_JOBS', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'Always on - Enable Primary Jobs and Disable Secondary jobs', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Go]    Script Date: 09/12/2021 14:52:22 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Go', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'-------------------------------------------------------------------------------------------------------
DECLARE @localReplicaRole int

select @localReplicaRole = Role from [master].sys.dm_hadr_availability_replica_states where is_local = 1;
-- Role = 1 => primary
-- Role = 2 => secondary

PRINT @localReplicaRole

IF (@localReplicaRole =2 )

BEGIN

-- Disables status of  jobs on secondary Always on server.  
USE MSDB ;  
       PRINT  ''SECONDARY FOUND DISABLING JOBS''

    EXEC dbo.sp_update_job  
        @job_name = N''DatabaseBackup - USER_DATABASES - FULL'',  
        @enabled = 0 ;  

    EXEC dbo.sp_update_job  
         @job_name = N''DatabaseBackup - USER_DATABASES - DIFF'',  
         @enabled = 0 ;  

    EXEC dbo.sp_update_job  
         @job_name = N''DatabaseBackup - USER_DATABASES - LOG'',  
         @enabled = 0 ;  

    EXEC dbo.sp_update_job  
         @job_name = N''DatabaseIntegrityCheck - USER_DATABASES'',  
         @enabled = 0 ;  

    EXEC dbo.sp_update_job  
         @job_name = N''IndexOptimize - USER_DATABASES'',  
         @enabled = 0 ;  

  EXEC dbo.sp_update_job  
         @job_name = N''Testjob '',  
         @enabled = 0

  EXEC dbo.sp_update_job  
         @job_name = N''Copy Personal Profile Data'',  
         @enabled = 0

  EXEC dbo.sp_update_job  
         @job_name = N''Daily Notifications'',  
         @enabled = 0

  EXEC dbo.sp_update_job  
         @job_name = N''EB088-Trace'',  
         @enabled = 0

  EXEC dbo.sp_update_job  
         @job_name = N''Leave Request Email'',  
         @enabled = 0

 EXEC dbo.sp_update_job  
         @job_name = N''MICAP_Outstanding'',  
         @enabled = 0

 EXEC dbo.sp_update_job  
         @job_name = N''Naval_CheckClosedMILSTRIPs'',  
         @enabled = 0

 EXEC dbo.sp_update_job  
         @job_name = N''Severity 1 & 2 Status Update Notification'',  
         @enabled = 0

 EXEC dbo.sp_update_job  
         @job_name = N''SLA Reporting'',  
         @enabled = 0

EXEC dbo.sp_update_job  
         @job_name = N''Truncate AD Data'',  
         @enabled = 0



END
     ELSE 
           BEGIN
                PRINT ''PRIMARY NODE JOBS ENABLED''
	USE MSDB ; 		
				
    EXEC dbo.sp_update_job  
        @job_name = N''DatabaseBackup - USER_DATABASES - FULL'',  
        @enabled = 1 ;  

    EXEC dbo.sp_update_job  
         @job_name = N''DatabaseBackup - USER_DATABASES - DIFF'',  
         @enabled = 1 ;  

    EXEC dbo.sp_update_job  
         @job_name = N''DatabaseBackup - USER_DATABASES - LOG'',  
         @enabled = 1 ;  

    EXEC dbo.sp_update_job  
         @job_name = N''DatabaseIntegrityCheck - USER_DATABASES'',  
         @enabled = 1 ;  

    EXEC dbo.sp_update_job  
         @job_name = N''IndexOptimize - USER_DATABASES'',  
         @enabled = 1 ;  

   EXEC dbo.sp_update_job  
         @job_name = N''Testjob'',  
         @enabled = 1

  EXEC dbo.sp_update_job  
         @job_name = N''Copy Personal Profile Data'',  
         @enabled = 1

  EXEC dbo.sp_update_job  
         @job_name = N''Daily Notifications'',  
         @enabled = 1

  EXEC dbo.sp_update_job  
         @job_name = N''EB088-Trace'',  
         @enabled = 1

  EXEC dbo.sp_update_job  
         @job_name = N''Leave Request Email'',  
         @enabled = 1

 EXEC dbo.sp_update_job  
         @job_name = N''MICAP_Outstanding'',  
         @enabled = 1

 EXEC dbo.sp_update_job  
         @job_name = N''Naval_CheckClosedMILSTRIPs'',  
         @enabled = 1

 EXEC dbo.sp_update_job  
         @job_name = N''Severity 1 & 2 Status Update Notification'',  
         @enabled = 1


 EXEC dbo.sp_update_job  
         @job_name = N''SLA Reporting'',  
         @enabled = 1

EXEC dbo.sp_update_job  
         @job_name = N''Truncate AD Data'',  
         @enabled = 1



 
           END
 --------------------------------------------------', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Every 5 mins', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=4, 
		@freq_subday_interval=5, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20211124, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959, 
		@schedule_uid=N'34e93bb5-5f54-4a37-aad6-d46ef80c4178'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

