---WORST 10 QUERIES BY ELAPSED TIME FOR ALL DATABASES ON THE INSTANCE
--------------------------------------------------------
---Adrian Sleigh 11/07/17
--------------------------------------------------------
sp_MSforeachdb 'Use [?]; Select 
db_name() AS [CURRENT DATABASE]
(SELECT TOP 10 
obj.name, 
max_logical_reads, 
max_logical_writes,
max_logical_reads + max_logical_writes as total_RW,
max_elapsed_time,
max_logical_reads + max_logical_writes/execution_count as execution_cost,
last_execution_time,
execution_count,[text]

FROM sys.dm_exec_query_stats a
CROSS APPLY sys.dm_exec_sql_text(sql_handle) hnd
INNER JOIN sys.sysobjects obj on hnd.objectid = obj.id)
ORDER BY max_elapsed_time DESC
'
---END