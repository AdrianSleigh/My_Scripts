----SCRIPT TO POPULATE THE MASTER SQL_MONITORING DATABASE
------------------------------------------------------------------
--ADRIAN SLEIGH V1.0 23/06/22
------------------------------------------------------------------


/****** Script for SelectTopNRows command from SSMS  ******/
TRUNCATE TABLE [M_SQL_Monitoring].[dbo].[M_LAST_BACKUP]
INSERT INTO [SLKBRHSQLDSCN02\DEVELOPMENT].[M_SQL_Monitoring].[dbo].[M_LAST_BACKUP]
(
[Server_Inst],[Run_date], [HA_Primary],[Database_name],[DaysSinceLastBackup],[LastBackupDate],[BackupType]
)

SELECT 
      
	   @@servername
      ,[Run_Date]
      ,[HA_Primary]
      ,[Database_Name]
      ,[DaysSinceLastBackup]
      ,[LastBackupDate]
      ,[BackupType]
  FROM [SQL_Monitoring].[dbo].[BACKUPS]
   WHERE Run_date >= Getdate()-1

---------------------------------------------------------------------------------------------------
TRUNCATE TABLE [M_SQL_Monitoring].[dbo].[M_BLOCKING]
INSERT INTO [SLKBRHSQLDSCN02\DEVELOPMENT].[M_SQL_Monitoring].[dbo].[M_BLOCKING]
([Server_Inst],[Ran_Date],[Spid],[Blocked],[LeadBlocker],[BObject],[WaitTime],[LastWaitType],[PhysicalIO],[LoginTime],[LastBatch],[OpenTran],[BStatus],[Hostname],[ProgramName],[LoginName]
)

SELECT

       @@servername
      ,[Ran_Date]
      ,[Spid]
      ,[Blocked]
      ,[LeadBlocker]
      ,[BObject]
      ,[WaitTime]
      ,[LastWaitType]
      ,[PhysicalIO]
      ,[LoginTime]
      ,[LastBatch]
      ,[OpenTran]
      ,[BStatus]
      ,[Hostname]
      ,[ProgramName]
      ,[LoginName]
 FROM [SQL_Monitoring].[dbo].[BLOCKING]
 --  WHERE Ran_date >= Getdate()-1
 --------------------------------------------------------------------------------------------------

 TRUNCATE TABLE [M_SQL_Monitoring].[dbo].[M_CONNECTION_MONITOR]
 INSERT INTO [SLKBRHSQLDSCN02\DEVELOPMENT].[M_SQL_Monitoring].[dbo].[M_CONNECTION_MONITOR]
 (
 [Server_Inst]
 ,[LoginName]
 ,[Host]
 ,[ProgName]
 ,[DbName]
 ,[Connections]
 ,[EarliestLogin]
 ,[LatestLogin]
 ,[Status]
 )

 SELECT

       @@servername
	   ,[LoginName]
	   ,[Host]
	   ,[ProgName]
	   ,[DbName]
	   ,[Connections]
	   ,[EarliestLogin]
	   ,[LatestLogin]
	   ,[Status]

FROM [SQL_Monitoring].[dbo].[CONNECTION_MONITOR]
--------------------------------------------------------------------------------------------------
TRUNCATE TABLE [M_SQL_Monitoring].[dbo].[M_CPU_DETAILS]
 INSERT INTO [SLKBRHSQLDSCN02\DEVELOPMENT].[M_SQL_Monitoring].[dbo].[M_CPU_DETAILS]
 (
 [Server_Inst]
,[Ran_date]
,[object_name]
,[text_data]
,[disk_reads]
,[memory_reads]
,[executions]
,[total_cpu_time]
,[average_cpu_time]
,[disk_wait_and_cpu_time]
,[memory_writes]
,[date_cached]
,[database_name]
,[last_execution]
)

SELECT

       @@servername
	   ,[Ran_date]
	   ,[object_name]
	   ,[text_data]
	   ,[disk_reads]
	   ,[memory_reads]
	   ,[executions]
	   ,[total_cpu_time]
	   ,[average_cpu_time]
	   ,[disk_wait_and_cpu_time]
	   ,[memory_writes]
	   ,[date_cached]
	   ,[database_name]
	   ,[last_execution]
FROM [SQL_Monitoring].[dbo].[CPU_DETAILS]
  WHERE Ran_date >= Getdate()-1
  ------------------------------------------------------------------------------------------
TRUNCATE TABLE [M_SQL_Monitoring].[dbo].[M_CPU_USAGE]
 INSERT INTO [SLKBRHSQLDSCN02\DEVELOPMENT].[M_SQL_Monitoring].[dbo].[M_CPU_USAGE]
 (
 [Server_Inst]
,[SQL_CPU_UTILISATION]
,[SYSTEM_IDLE]
,[OTHER_CPU_UTILISATION]
,[EVENT_TIME]
)

SELECT

       @@servername
	   ,[SQL_CPU_UTILISATION]
	   ,[SYSTEM_IDLE]
	   ,[OTHER_CPU_UTILISATION]
	   ,[EVENT_TIME]
FROM [SQL_Monitoring].[dbo].[CPU_USAGE]

--------------------------------------------------------------------------------------------

TRUNCATE TABLE [M_SQL_Monitoring].[dbo].[M_DB_ACTIVITY]
 INSERT INTO [SLKBRHSQLDSCN02\DEVELOPMENT].[M_SQL_Monitoring].[dbo].[M_DB_ACTIVITY]
 (
 [Server_Inst]
 ,[collected_date]
 ,[TotalPageReads]
 ,[TotalPageWrites]
 ,[Databasename]
 )
 SELECT

       @@servername
	   ,[collected_date]
	   ,[TotalPageReads]
	   ,[TotalPageWrites]
	   ,[Databasename]

FROM [SQL_Monitoring].[dbo].[DB_ACTIVITY]
  WHERE [collected_date] >= Getdate()-1
  --------------------------------------------------------------------------------------------

  
TRUNCATE TABLE [M_SQL_Monitoring].[dbo].[M_DB_SIZES]
 INSERT INTO [SLKBRHSQLDSCN02\DEVELOPMENT].[M_SQL_Monitoring].[dbo].[M_DB_SIZES]
 (
[Server_Inst]
,[RAN_DATE]
,[DB_NAME]
,[DB_STATUS]
,[RECOVERY_MODEL]
,[DB_SIZE]
,[FILE_SIZE_MB]
,[SPACE_USED_MB]
,[FREE_SPACE_MB]
,[LOG_FILE_MB]
,[LOG_SPACE_USED_MB]
,[LOG_FREE_SPACE_MB]
,[DB_FREESPACE]
)

SELECT

       @@servername
	   ,[RAN_DATE]
	   ,[DB_NAME]
	   ,[DB_STATUS]
	   ,[RECOVERY_MODEL]
	   ,[DB_SIZE]
	   ,[FILE_SIZE_MB]
	   ,[SPACE_USED_MB]
	   ,[FREE_SPACE_MB]
	   ,[LOG_FILE_MB]
	   ,[LOG_SPACE_USED_MB]
	   ,[LOG_FREE_SPACE_MB]
	   ,[DB_FREESPACE]
	   
FROM [SQL_Monitoring].[dbo].[DB_SIZES]
  WHERE [RAN_DATE] >= Getdate()-1
    --------------------------------------------------------------------------------------------

	TRUNCATE TABLE [M_SQL_Monitoring].[dbo].[M_DRIVE_SPACE_FREE]
 INSERT INTO [SLKBRHSQLDSCN02\DEVELOPMENT].[M_SQL_Monitoring].[dbo].[M_DRIVE_SPACE_FREE]
 (
[Server_Inst]
,[Ran_Date]
,[Drive]
,[Total_Space_GB]
,[Free_Space_GB]
,[percent_Free_GB]
)

SELECT

       @@servername
	   ,[Ran_Date]
	   ,[Drive]
	   ,[Total_Space_GB]
	   ,[Free_Space_GB]
	   ,[percent_Free_GB]

FROM [SQL_Monitoring].[dbo].[DRIVE_SPACE_FREE]
 -- WHERE [RAN_DATE] >= Getdate()-1
  --------------------------------------------------------------------------------------------

TRUNCATE TABLE [M_SQL_Monitoring].[dbo].[M_FAILED_LOGINS]
INSERT INTO [SLKBRHSQLDSCN02\DEVELOPMENT].[M_SQL_Monitoring].[dbo].[M_FAILED_LOGINS]
 (
 [Server_Inst]
,[NumberOfAttempts]
,[Details]
,[MinLogDate]
,[MaxLogDate]
)

SELECT

      @@servername
	  ,[NumberOfAttempts]
	  ,[Details]
	  ,[MinLogDate]
	  ,[MaxLogDate]
	  
	  FROM [SQL_Monitoring].[dbo].[FAILED_LOGINS]
 -- WHERE [RAN_DATE] >= Getdate()-1
   --------------------------------------------------------------------------------------------

TRUNCATE TABLE [M_SQL_Monitoring].[dbo].[M_FRAGMENTATION]
INSERT INTO [SLKBRHSQLDSCN02\DEVELOPMENT].[M_SQL_Monitoring].[dbo].[M_FRAGMENTATION]
(
 [Server_Inst]
 ,