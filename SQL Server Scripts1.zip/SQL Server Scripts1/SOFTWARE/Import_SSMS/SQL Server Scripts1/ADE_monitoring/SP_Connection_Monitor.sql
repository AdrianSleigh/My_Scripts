USE [SQL_Monitoring]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Adrian Sleigh
-- Create date: 2018/11/20
-- Description:	Connection Monitor
-- =============================================
CREATE PROCEDURE [dbo].[sp_Connection_Monitor] 
	-- Add the parameters for the stored procedure here
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

-- Create the data table if its not already there
	IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'dbo.Connection_Monitor') and OBJECTPROPERTY(id, N'IsTable') = 1)
	BEGIN
		CREATE TABLE dbo.CONNECTION_MONITOR
		(
			[ID] [int]		IDENTITY(1,1) NOT NULL,
--			SessId			INT,
			LoginName		NVARCHAR(100),
			Host			NVARCHAR(100),
			ProgName		NVARCHAR(100),
			DbName			NVARCHAR(50),
			Connections		INT,
			EarliestLogin	DATETIME,
			LatestLogin		DATETIME,
			[Status]		NVARCHAR(100)
		)
	END

-- Create a temporary store for extract
	IF OBJECT_ID('tempdb..#tabConnMon') IS NULL
	BEGIN
		CREATE TABLE #tabConnMon
		(
			[ID] [int]		IDENTITY(1,1) NOT NULL,
--			SessId			INT,
			LoginName		NVARCHAR(100),
			Host			NVARCHAR(100),
			ProgName		NVARCHAR(100),
			DbName			NVARCHAR(50),
			Connections		INT,
			EarliestLogin	DATETIME,
			LatestLogin		DATETIME,
			[Status]		NVARCHAR(100)
		)
	END

-- Extract from system tables to temp table grouping by user, host, prog
	BEGIN
		INSERT INTO
			#tabConnMon
		(
--			SessId,
			LoginName,
			Host,
			ProgName,
			DbName,
			Connections,
			EarliestLogin,
			LatestLogin,
			[Status]
		)
		SELECT
--			A.spid,
			LEFT(ISNULL(A.loginame, ''), 100) AS LoginName,
			LEFT(ISNULL(A.hostname, ''), 100) AS Host,
			LEFT(ISNULL(B.program_name, ''), 100),
			DB_NAME(LEFT(ISNULL(A.dbid, ''), 50)) AS DBName, 
			COUNT(A.dbid) AS NumberOfConnections,
			MIN(A.login_time) AS EarliestLogin,
			MAX(A.login_time) AS LatestLogin,
			LEFT(A.status, 100) AS Status
		FROM
			sys.sysprocesses AS A
		LEFT OUTER JOIN
            sys.dm_exec_sessions AS B
		ON
			A.spid = B.session_id
		WHERE 
			A.dbid > 4
		GROUP BY 
--			A.spid,
			A.dbid, A.hostname, B.program_name, A.loginame, A.status
	END

-- Save results to data table without duplicating Login, Host, Prog and DbName
	BEGIN
		INSERT INTO
			dbo.Connection_Monitor
		(
--			SessId,
			LoginName,
			Host,
			ProgName,
			DbName,
			Connections,
			EarliestLogin,
			LatestLogin,
			[Status]
		)
		SELECT
--			#tabConnMon.SessId,
			#tabConnMon.LoginName,
			#tabConnMon.Host,
			#tabConnMon.ProgName,
			#tabConnMon.DbName,
			#tabConnMon.Connections,
			#tabConnMon.EarliestLogin,
			#tabConnMon.LatestLogin,
			#tabConnMon.[Status]
		FROM
			#tabConnMon
		LEFT OUTER JOIN
            Connection_Monitor
		ON
			#tabConnMon.LoginName = dbo.Connection_Monitor.LoginName
		AND
			#tabConnMon.Host = dbo.Connection_Monitor.Host
		AND 
			#tabConnMon.ProgName = dbo.Connection_Monitor.ProgName
		AND
			#tabConnMon.DbName = dbo.Connection_Monitor.DbName
		WHERE
			(dbo.Connection_Monitor.ID IS NULL)
	END

 -- Update latest login and status where login, host, prog and db are the same
	BEGIN
		UPDATE
			dbo.Connection_Monitor
		SET
			dbo..LatestLogin = dbo.#tabConnMon.LatestLogin,
			dbo.Connection_Monitor.Status = dbo.#tabConnMon.Status
		FROM
			dbo.Connection_Monitor
		INNER JOIN
			dbo.#tabConnMon
		ON
			dbo.Connection_Monitor.LoginName = dbo.#tabConnMon.LoginName
		AND
			dbo.Connection_Monitor.Host = dbo.#tabConnMon.Host
		AND 
			dbo.Connection_Monitor.ProgName = dbo.#tabConnMon.ProgName
		AND 
			dbo.Connection_Monitor.DbName = dbo.#tabConnMon.DbName
	END

--SELECT * FROM dbo.Connection_Monitor

-- Remove temp table
	BEGIN
		IF OBJECT_ID('tempdb..#tabConnMon') IS NOT NULL DROP TABLE #tabConnMon
	END
END

------------------------------------------------------
---JOB------
USE [msdb]
GO

/****** Object:  Job [sp_ConnectionMonitor]    Script Date: 03/02/2022 14:59:41 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[STATISTICS]]    Script Date: 03/02/2022 14:59:41 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[STATISTICS]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[STATISTICS]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'sp_ConnectionMonitor', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[STATISTICS]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Collect user connections]    Script Date: 03/02/2022 14:59:41 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Collect user connections', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC sp_ConnectionMonitor', 
		@database_name=N'SQL_Monitoring', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Every 15 mins', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=4, 
		@freq_subday_interval=15, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20220203, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959 
	
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO
----------------------------------------------------------------


