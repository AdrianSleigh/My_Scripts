--------Busiest_databases
---Adrian Sleigh 06/02/22
------------------------------------
USE [SQL_Monitoring]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DB_ACTIVITY]') AND type in (N'U'))
DROP TABLE [dbo].[DB_ACTIVITY]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[DB_ACTIVITY](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[collected_date] [smalldatetime] NOT NULL,
	[TotalPageReads] [int] NOT NULL,
	[TotalPageWrites] [int] NOT NULL,
	[Databasename] [nchar](60) NOT NULL
) ON [PRIMARY]
GO

---BUSIEST DATABASES INSERT
---Adrian Sleigh 06/02/22
-----------------------------------------------------------------

INSERT INTO SQL_Monitoring.dbo.DB_ACTIVITY (collected_date,TotalPageReads,TotalPageWrites,Databasename)

SELECT 
getdate() AS collected_date,
SUM(deqs.total_logical_reads) TotalPageReads,
SUM(deqs.total_logical_writes) TotalPageWrites, 
CASE
WHEN DB_NAME(dest.dbid) IS NULL THEN 'AdhocSQL'
ELSE DB_NAME(dest.dbid) END Databasename
FROM sys.dm_exec_query_stats deqs
CROSS APPLY sys.dm_exec_sql_text(deqs.sql_handle) AS dest
GROUP BY DB_NAME(dest.dbid)

-----------------------------------------------------------------
---BUSIEST DATABASES JOB
---Adrian Sleigh 06/02/22

USE [msdb]
GO
DECLARE @jobId BINARY(16)
EXEC  msdb.dbo.sp_add_job @job_name=N'Database-Usage', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_page=2, 
		@delete_level=0, 
		@category_name=N'[STATISTICS]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
select @jobId
GO
EXEC msdb.dbo.sp_add_jobserver @job_name=N'Database-Usage', @server_name = N'SLKBRHPSQ01\DBTESTING'
GO
USE [msdb]
GO
EXEC msdb.dbo.sp_add_jobstep @job_name=N'Database-Usage', @step_name=N'Go', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_fail_action=2, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'INSERT INTO SQL_Monitoring.dbo.DB_ACTIVITY (collected_date,TotalPageReads,TotalPageWrites,Databasename)

SELECT 
getdate() AS collected_date,
SUM(deqs.total_logical_reads) TotalPageReads,
SUM(deqs.total_logical_writes) TotalPageWrites, 
CASE
WHEN DB_NAME(dest.dbid) IS NULL THEN ''AdhocSQL''
ELSE DB_NAME(dest.dbid) END Databasename
FROM sys.dm_exec_query_stats deqs
CROSS APPLY sys.dm_exec_sql_text(deqs.sql_handle) AS dest
GROUP BY DB_NAME(dest.dbid)', 
		@database_name=N'SQL_Monitoring', 
		@flags=0
GO
USE [msdb]
GO
EXEC msdb.dbo.sp_update_job @job_name=N'Database-Usage', 
		@enabled=1, 
		@start_step_id=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_page=2, 
		@delete_level=0, 
		@description=N'', 
		@category_name=N'[STATISTICS]', 
		@owner_login_name=N'sa', 
		@notify_email_operator_name=N'', 
		@notify_page_operator_name=N''
GO
USE [msdb]
GO
DECLARE @schedule_id int
EXEC msdb.dbo.sp_add_jobschedule @job_name=N'Database-Usage', @name=N'Daily', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20220206, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959, @schedule_id = @schedule_id OUTPUT
select @schedule_id
GO
--------------------------------------------------------------------
