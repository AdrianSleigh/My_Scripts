---BLOCKING
--Adrian Sleigh 28/02/22
-------------------------------------------------
IF OBJECT_ID(N'tempdb..#tmp_Blocking') IS NOT NULL
BEGIN
DROP TABLE #tmp_Blocking
END
GO
BEGIN
SELECT  getdate() AS 'RanDate' 
  , p.spid
  , p.blocked
  , ISNULL(l.spid, 0) AS 'LeadBlocker'
  , d.name
  , p.waittime
  , p.lastwaittype
  , p.physical_io
  , p.login_time
  , p.last_batch
  , p.open_tran
  , p.status
  , p.hostname
  , p.program_name
  , p.net_address
  , p.loginame
  INTO #tmp_Blocking

FROM sysprocesses p
 INNER JOIN sysdatabases d
  ON p.dbid = d.dbid
 LEFT OUTER JOIN (SELECT spid 
      FROM  master..sysprocesses a
         WHERE  exists ( SELECT b.*
                FROM master..sysprocesses b
                WHERE b.blocked > 0 
          AND b.blocked = a.spid ) 
           AND NOT
           EXISTS ( SELECT b.*
              FROM master..sysprocesses b
              WHERE b.blocked > 0 
              AND b.spid = a.spid )) l
     ON p.spid = l.spid
WHERE p.spid > 50
AND p.blocked <> 0
OR  l.spid <> 0
END

SELECT * FROM #tmp_Blocking
BEGIN
DELETE #tmp_Blocking
END