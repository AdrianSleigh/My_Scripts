------counts rows with much lower performance hit
------------------------------------------------
DECLARE @TableName sysname
SET @TableName = 'table_name_here'

SELECT OBJECT_NAME(object_id), SUM(row_count) AS rows
FROM sys.dm_db_partition_stats
WHERE object_id = OBJECT_ID(@TableName)
AND index_id < 2
GROUP BY OBJECT_NAME(object_id);