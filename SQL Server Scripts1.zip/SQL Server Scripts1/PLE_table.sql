---Create Page life expectancy table
---for storing info  create job every  few mins to catch
---------------------------------------------------------
USE [DBA_Admin]
GO

/****** Object:  Table [dbo].[PLE]    Script Date: 23/11/2020 16:59:23 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[PLE](
	[id] [smallint] IDENTITY(1,1) NOT NULL,
	[TimeRan] [smalldatetime] NOT NULL,
	[Countername] [nchar](25) NOT NULL,
	[PagelifeValue] [smallint] NOT NULL
) ON [PRIMARY]
GO
