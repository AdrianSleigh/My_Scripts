-----INSTANCE LEVEL LAST USED OBJECTS
----LAST USED DATABASE
----------------------------------------------------------------------------
SELECT 
(SELECT sqlserver_start_time FROM sys.dm_os_sys_info)As Last_SQL_Restart, 
d.name,
last_user_seek = MAX(last_user_seek),
last_user_scan = MAX(last_user_scan),
last_user_lookup = MAX(last_user_lookup),
last_user_update = MAX(last_user_update)
FROM sys.dm_db_index_usage_stats AS i
JOIN sys.databases AS d ON i.database_id=d.database_id
WHERE d.name NOT IN ('master','msdb','tempdb')
GROUP BY d.name

