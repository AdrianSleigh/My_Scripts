--RESIZING TEMPDB
----29/01/21 Adrian Sleigh
-- configured size
SELECT 
name, file_id, type_desc, size * 8 / 1024 [ConfigureSize_MB]
FROM sys.master_files
WHERE DB_NAME(database_id) = 'tempdb'
ORDER BY type_desc DESC, file_id 
GO

-- current size
SELECT 
name, file_id, type_desc, size * 8 / 1024 [CurrentSize_MB] 
FROM tempdb.sys.database_files 
ORDER BY type_desc DESC, file_id
GO

sp_helpdb 'tempdb'

/*
USE [master]
GO
ALTER DATABASE [tempdb] MODIFY FILE ( NAME = N'templog',  SIZE = 512000KB , FILEGROWTH = 50MB )
ALTER DATABASE [tempdb] MODIFY FILE ( NAME = N'tempdev',  SIZE = 512000KB , FILEGROWTH = 50MB )
ALTER DATABASE [tempdb] MODIFY FILE ( NAME = N'tempdev1', SIZE = 512000KB , FILEGROWTH = 50MB )
ALTER DATABASE [tempdb] MODIFY FILE ( NAME = N'tempdev2', SIZE = 512000KB , FILEGROWTH = 50MB )
ALTER DATABASE [tempdb] MODIFY FILE ( NAME = N'tempdev3', SIZE = 512000KB , FILEGROWTH = 50MB )
ALTER DATABASE [tempdb] MODIFY FILE ( NAME = N'tempdev4', SIZE = 512000KB , FILEGROWTH = 50MB )
ALTER DATABASE [tempdb] MODIFY FILE ( NAME = N'tempdev5', SIZE = 512000KB , FILEGROWTH = 50MB )
ALTER DATABASE [tempdb] MODIFY FILE ( NAME = N'tempdev6', SIZE = 512000KB , FILEGROWTH = 50MB )
ALTER DATABASE [tempdb] MODIFY FILE ( NAME = N'tempdev7', SIZE = 512000KB , FILEGROWTH = 50MB )
*/
--to remove

USE [tempdb]
GO
ALTER DATABASE [tempdb]  REMOVE FILE [tempdev8]
GO

USE [tempdb];
GO
DBCC SHRINKFILE (tempdev8, EMPTYFILE);
GO