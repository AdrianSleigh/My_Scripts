--=-query the baseline-table

WITH ATrace (
[StartTime],[EndTime],[TotalMinutes],[TotalOperations],
[TotalCPU],[TotalReads],[TotalWrites],[TotalDuration])
AS (
       SELECT
                CONVERT(varchar(10), MIN(StartTime),8),
                CONVERT(varchar(10), MAX(EndTime),8),
                DATEDIFF(n,MIN(StartTime),MAX(EndTime)),
                COUNT(RowNumber),
                SUM(CPU),
                SUM(Reads),
                SUM(Writes),
                SUM(Duration)
        FROM
                BASELINE 
)

SELECT
        StartTime [Start],
        EndTime [End],
        TotalMinutes [Total Mins],
        TotalOperations [Total Ops.],
        TotalCPU,
        TotalReads,
        TotalWrites,
        TotalDuration,
        CAST((CAST(TotalOperations as decimal(18,4)) / 
            CAST(TotalMinutes as decimal(18,4))) as decimal 
                (18,4))[Ops / Min.],
        CAST((CAST(ISNULL(TotalCPU,0) as decimal(18,4)) / 
            CAST(TotalOperations as decimal(18,4))) as decimal
                (18,4)) [CPU / Op],
        CAST((CAST(ISNULL(TotalReads,0) as decimal(18,4)) / 
            CAST(TotalOperations as decimal(18,4))) as decimal
                (18,4)) [Reads / Op],
        CAST((CAST(ISNULL(TotalWrites,0) as decimal(18,4)) / 
            CAST(TotalOperations as decimal(18,4))) as decimal
                (18,4)) [Writes / Op],
        CAST((CAST(ISNULL(TotalDuration,0) as decimal(18,4)) / 
            CAST(TotalOperations as decimal(18,4))) as decimal
                (18,4)) [Duration / Op]
FROM 
        ATrace;