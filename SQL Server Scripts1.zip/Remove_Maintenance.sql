-------------------REMOVE MAINTENANCE OBJECTS AND JOBS---------------
---------------------------------------------------------------------
USE [msdb]
GO
IF  EXISTS (SELECT * FROM sys.tables WHERE [name] like 'CommandLog')
DROP TABLE [dbo].[CommandLog]
------------------------------------------------------------------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CommandExecute]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[CommandExecute]
------------------------------------------------------------------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DatabaseBackup]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[DatabaseBackup]
------------------------------------------------------------------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DatabaseIntegrityCheck]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[DatabaseIntegrityCheck]
------------------------------------------------------------------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[IndexOptimize]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[IndexOptimize]
----------------------------------------------------------------------------------------------------
USE [msdb]
GO
/**************DROP JOBS*************************************/
IF  EXISTS (SELECT * FROM sysjobs WHERE [name] like 'DDC_Backup_FULL_DBS')
EXEC msdb.dbo.sp_delete_job @job_name=N'DDC_Backup_FULL_DBS', @delete_unused_schedule=1
GO
--------------------------------------------------------------------
IF  EXISTS (SELECT * FROM sysjobs WHERE [name] like 'DDC_Backup_USER_TLOG_DBS')
EXEC msdb.dbo.sp_delete_job @job_name=N'DDC_Backup_USER_TLOG_DBS', @delete_unused_schedule=1
GO
-------------------------------------------------------------------
IF  EXISTS (SELECT * FROM sysjobs WHERE [name] like 'DDC_IndexOptimize_USER_DBS')
EXEC msdb.dbo.sp_delete_job @job_name=N'DDC_IndexOptimize_USER_DBS', @delete_unused_schedule=1
GO
------------------------------------------------------------------
IF  EXISTS (SELECT * FROM sysjobs WHERE [name] like 'DDC_IntegrityChecks')
EXEC msdb.dbo.sp_delete_job @job_name=N'DDC_IntegrityChecks', @delete_unused_schedule=1
GO
-----------------------------------------------------------------
IF  EXISTS (SELECT * FROM sysjobs WHERE [name] like 'DDC_Tidy_CycleErrorLog')
EXEC msdb.dbo.sp_delete_job @job_name=N'DDC_Tidy_CycleErrorLog', @delete_unused_schedule=1
GO
-----------------------------------------------------------------
IF  EXISTS (SELECT * FROM sysjobs WHERE [name] like 'DDC_Database_BackupCheck')
EXEC msdb.dbo.sp_delete_job @job_name=N'DDC_Database_BackupCheck', @delete_unused_schedule=1
GO
-----------------------------------------------------------------
IF  EXISTS (SELECT * FROM sysjobs WHERE [name] like 'DDC_Backup_DIFF_DBS')
EXEC msdb.dbo.sp_delete_job @job_name=N'DDC_Backup_DIFF_DBS', @delete_unused_schedule=1
GO
-----------------------------------------------------------------
IF  EXISTS (SELECT * FROM sysjobs WHERE [name] like 'DDC_A_Initial_Test_All_Maintenance_Jobs')
EXEC msdb.dbo.sp_delete_job @job_name=N'DDC_A_Initial_Test_All_Maintenance_Jobs', @delete_unused_schedule=1
GO
-----------------------------END---------------------------------

