
--FIND A DATABASE
select 
[name],[filename],[cmptlevel],[crdate],[version]

from sysdatabases where name like '%icps%'