USE [_Demo_Decomm_1]
GO
--1-- disable related jobs (jobs that have T-SQL step with a database name selected for the step)
SELECT j.* FROM msdb.dbo.sysjobsteps js
 JOIN msdb.dbo.sysjobs j ON js.job_id = j.job_id
WHERE j.[enabled] = 1 AND js.database_name = DB_NAME()

-- disable every job found with the query above
EXEC msdb.dbo.sp_update_job
    @job_name = N'Export Some Data',
    @enabled = 1 ;
    
-- there could be other jobs that are related to the database. 
-- For example, scheduled SSIS packages.

--2---  
USE [_Demo_Decomm_1]
GO
CREATE TABLE dbo.##temp_logins (sid VARBINARY(200), db NVARCHAR(128));

EXEC sys.sp_MSforeachdb 
 'INSERT INTO dbo.##temp_logins 
  SELECT sid, ''?''  FROM [?].sys.database_principals 
   WHERE type IN (''S'', ''U'', ''G'') -- SQL Logins, Windows Logins and Windows Groups
   AND authentication_type > 0 --excludes schemas and users without logins in contained databases
   AND principal_id > 1 -- dbo';

SELECT sp.name as Login_Name, 
 CASE WHEN all_dbs.db IS NOT NULL THEN '-- Exists in ' + all_dbs.db +  ' database'   
  WHEN sr.member_principal_id IS NOT NULL THEN '-- Is member of the ' + r.name + ' server role ' 
  ELSE 'ALTER LOGIN [' + sp.name + '] DISABLE ; ' END as "Keep/Disable Login"
FROM tempdb.dbo.##temp_logins c_db -- current database (to decommission)
 JOIN sys.server_principals sp 
  ON c_db.sid = sp.sid
 LEFT JOIN  sys.server_role_members sr
  ON sp.principal_id = sr.member_principal_id
 LEFT JOIN sys.server_principals AS r
    ON sr.role_principal_id = r.principal_id
 LEFT JOIN tempdb.dbo.##temp_logins all_dbs
  ON c_db.sid = all_dbs.sid and all_dbs.db != DB_NAME()

WHERE c_db.db = DB_NAME() ;
 
DROP TABLE dbo.##temp_logins;

--3-- 
USE [_Demo_Decomm_1]
GO
-- check DB connections
SELECT login_time, [host_name], [program_name] 
FROM sys.dm_exec_sessions WHERE database_id = DB_ID();

--4--
SELECT name, is_published, is_merge_published, is_distributor FROM master.sys.databases

--5--
--check filestream enabled
USE [_Demo_Decomm_1]
GO
-- FILESTREAM
SELECT DB_NAME(database_id), non_transacted_access, non_transacted_access_desc
    FROM sys.database_filestream_options;
--
USE [_Demo_Decomm_1]
GO
-- FileTables
SELECT * FROM sys.filetables;
GO
SELECT * FROM sys.tables WHERE is_filetable = 1;
GO

--check full text

USE [_Demo_Decomm_1]
GO
-- full-text catalogs
SELECT name FROM sys.fulltext_catalogs

--check cross db references
-- cross-db dependencies
CREATE   TABLE #tmp_dependencies (
   referencing_db_name NVARCHAR(128),
   referencing_object NVARCHAR(128),
   referenced_database_name NVARCHAR(128),
   referenced_schema_name NVARCHAR(128),
   referenced_entity_name NVARCHAR(128))
GO

EXEC sys.sp_MSforeachdb 'INSERT INTO #tmp_dependencies
SELECT  ''?'' AS referencing_db_name, 
  OBJECT_NAME (referencing_id) AS referencing_object, 
  referenced_database_name, 
      referenced_schema_name, 
      referenced_entity_name
FROM [?].sys.sql_expression_dependencies
WHERE referenced_database_name IS NOT NULL
      AND is_ambiguous = 0
   AND referenced_database_name = ''_Demo_Decomm_1'';'
 
SELECT * FROM #tmp_dependencies;

DROP TABLE #tmp_dependencies;
GO

-- check synonyms
-- synonyms
CREATE   TABLE #tmp_synonyms (
   referencing_db_name NVARCHAR(128),
   synonym_name NVARCHAR(128),
   base_object_name NVARCHAR(1035))
GO

EXEC sys.sp_MSforeachdb 'INSERT INTO #tmp_synonyms
SELECT  ''?'' AS referencing_db_name,  name AS synonym_name, base_object_name 
FROM [?].sys.synonyms WHERE base_object_name LIKE ''[[]_Demo_Decomm_1].%'';'
 
SELECT * FROM #tmp_synonyms;

DROP TABLE #tmp_synonyms;
GO

--check linked server
USE [master]
GO
SELECT name, product, provider, data_source, provider_string, [catalog]
 FROM sys.servers WHERE is_linked = 1

--check file location
USE [_Demo_Decomm_1]
GO
SELECT file_id, type_desc, data_space_id, name, physical_name FROM sys.database_files

--check clr dependancy
USE [_Demo_Decomm_1]
GO
-- CLR
SELECT name, clr_name, is_user_defined FROM sys.assemblies 

--check service broker dependancies
USE [_Demo_Decomm_1]
GO
-- Service Broker dependencies
SELECT * FROM  sys.service_queues WHERE is_ms_shipped = 0

--check audit specs

USE [_Demo_Decomm_1]
GO
-- DB audit
SELECT name, is_state_enabled FROM sys.database_audit_specifications

--check DDL triggers
USE master
GO
-- Server Level DDL triggers
SELECT t.name, m.[definition] 
 FROM sys.server_sql_modules m
  JOIN sys.server_triggers t ON m.object_id = t.object_id 
 WHERE [definition] LIKE '%Demo_Decomm_1%'

--proxy accounts
USE [master]
GO
SELECT  j.name AS job_name, js.step_name, p.proxy_id, 
  p.name AS proxy_name, p.credential_id, l.name AS login_name,
  c.name AS credential_name 
 FROM msdb.dbo.sysproxies p 
  JOIN sys.syslogins l ON p.user_sid = l.sid 
  JOIN sys.credentials c ON p.credential_id = c.credential_id
  JOIN msdb.dbo.sysjobsteps js ON p.proxy_id = js.proxy_id
  JOIN msdb.dbo.sysjobs j ON js.job_id = j.job_id
ORDER BY  j.name

--verify encryption
USE [_Demo_Decomm_1]
GO
SELECT * FROM sys.dm_database_encryption_keys
WHERE database_id = DB_ID();

SELECT name, key_length, algorithm_desc, create_date, modify_date
FROM sys.symmetric_keys;

SELECT name, algorithm_desc 
FROM sys.asymmetric_keys;

SELECT name, subject, start_date, expiry_date 
FROM sys.certificates;

--check resource governor
--- Get the classifier function Id and state (enabled).
SELECT * FROM sys.resource_governor_configuration
GO
--- Get the classifier function name and the name of the schema
--- that it is bound to.
SELECT * ,
      object_schema_name(classifier_function_id) AS [schema_name],
      object_name(classifier_function_id) AS [function_name]
FROM sys.dm_resource_governor_configuration

--review extended events
USE [master]
GO
SELECT e.event_session_id, s.name, e.predicate 
 FROM sys.server_event_session_events e
  JOIN   sys.server_event_sessions s ON e.event_session_id = s.event_session_id
WHERE predicate LIKE '%source_database_id%' OR  predicate LIKE '%database_name%';

--review alerts
USE [_Demo_Decomm_1]
GO
-- alerts
SELECT * FROM msdb.dbo.sysalerts 
WHERE database_name = DB_NAME() -- SQL Server event alerts for DB
 OR performance_condition LIKE '%' + DB_NAME() + '%' -- performance condition alerts

--set db offline

ALTER DATABASE [_Demo_Decomm_1] SET OFFLINE;



