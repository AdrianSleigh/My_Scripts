--shrinkfile


select name,fileid from sysfiles

DBCC SHRINKFILE (2, 0, TRUNCATEONLY)
GO