-----remove logshipping primary
EXEC master.dbo.sp_delete_log_shipping_primary_secondary  
@primary_database = N'DNNPublic_Live'  
,@secondary_server = N'DNNDRDB'  
,@secondary_database = N'DNNPublic_Live';  
GO  

 EXEC master.dbo.sp_delete_log_shipping_primary_database
 @database = 'DNNPublic_Live';
 GO

 ---then need to run on secondary the below
 EXEC master.dbo.sp_delete_log_shipping_secondary_database
 @secondary_database = 'DNNPublic_Live';
 GO
